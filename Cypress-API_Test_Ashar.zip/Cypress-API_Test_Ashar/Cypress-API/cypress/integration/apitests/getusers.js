/// <reference types = "Cypress"/>

describe('get api user tests',()=>{

    it('get all users',()=>{
      
        cy.request({
            method : 'GET',
            url : 'https://reqres.in/api/users'
        }).then((res)=>{
            expect(res.status).to.eq(200)

        })
    })
})


