/// <reference types = "Cypress"/>

describe('get api user tests',()=>{

    it('get single user and verify first name is Janet',()=>{
      
        cy.request({
            method : 'POST',
            url : 'https://reqres.in/api/users/',
            body: {
                "name": "morpheus",
                "job": "leader"
            }
        }).then((res)=>{
            expect(res.status).to.eq(201)
            expect(res.body.data).has.property('name','morpheus')
            expect(res.body.data).has.property('job','leader')

        })
    })
})


