/// <reference types = "Cypress"/>

describe('get api user tests',()=>{

    it('get all users',()=>{
      
        cy.request({
            method : 'GET',
            url : 'https://reqres.in/api/unknown'
        }).then((res)=>{
            expect(res.status).to.eq(200)
            expect(res.body.data[0].name).to.eq('cerulean')
            expect(res.body.data[1].name).to.eq('fuchsia rose')
            expect(res.body.data[2].name).to.eq('true red')
            expect(res.body.data[3].name).to.eq('aqua sky')
            expect(res.body.data[4].name).to.eq('tigerlily')
            expect(res.body.data[5].name).to.eq('blue turquoise')

        })
    })
})


