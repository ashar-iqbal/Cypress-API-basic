/// <reference types = "Cypress"/>

describe('get api user tests',()=>{

    it('get single user and verify first name is Janet',()=>{
      
        cy.request({
            method : 'GET',
            url : 'https://reqres.in/api/users/2'
        }).then((res)=>{
            expect(res.status).to.eq(200)
            expect(res.body.data.first_name).to.eq('Janet')

        })
    })
})


